/* SELECTORS */

export const getAllRegions = ({regions}) => regions;
export const getRegion = ({regions}, regionCode) => regions[regionCode];

/* ACTIONS */

/*
// action name creator
const reducerName = 'regions';
const createActionName = name => `app/${reducerName}/${name}`;

// action types


// action creators


// reducer
export default function reducer(statePart = [], action = {}) {
  switch (action.type) {
    default:
      return statePart;
  }
}
*/
