/* SELECTORS */

export const getAllTags = ({tags}) => tags;
export const getTagByName = ({tags}, tagName) => tags[tagName];

/* ACTIONS */

/*
// action name creator
const reducerName = 'tags';
const createActionName = name => `app/${reducerName}/${name}`;

// action types


// action creators


// reducer
export default function reducer(statePart = [], action = {}) {
  switch (action.type) {
    default:
      return statePart;
  }
}
*/
