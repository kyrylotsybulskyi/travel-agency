/* SELECTORS */

export const getAllSubregions = ({subregions}) => subregions;
export const getSubregion = ({subregions}, subregionCode) => subregions[subregionCode];

/* ACTIONS */

/*
// action name creator
const reducerName = 'subregions';
const createActionName = name => `app/${reducerName}/${name}`;

// action types


// action creators


// reducer
export default function reducer(statePart = [], action = {}) {
  switch (action.type) {
    default:
      return statePart;
  }
}
*/
